//
//  CountryTableViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/12/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import CoreData

//controller to show Core Data information

class CountryTableViewController: UITableViewController {

    var countryCoreArray : [CountryCore] = []
    
    var fetchedResultsController : NSFetchedResultsController!
    var managedObjectContext : NSManagedObjectContext!
    
    let getDataManager = GetDataManager.sharedInstance
    
    let locationManager = LocationsManager.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        // Do any additional setup after loading the view.
        //Get the app Managed object context
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        managedObjectContext = appDelegate.managedObjectContext
        
        //Setup the fetched results controller
        //Setup the fetch request
        let fetchRequest = NSFetchRequest()
        //Determines in what order we sort the results by
        let sortDescriptor = NSSortDescriptor(key: "countryName", ascending: true)
        //Pass the sort descriptors into an array for the fetch request
        fetchRequest.sortDescriptors = [sortDescriptor]
        //Set the entity so the fetch request knows what to fetch
        let entity = NSEntityDescription.entityForName("CountryCore", inManagedObjectContext: managedObjectContext)
        fetchRequest.entity = entity
        //Set the fetchedResultsController
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: "Root")
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        do {
            try fetchedResultsController.performFetch()
            
            countryCoreArray = fetchedResultsController.fetchedObjects as! [CountryCore]
            
            tableView.reloadData()
        } catch {
            
        }
        
    }
    
    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return countryCoreArray.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        let currentCountry = countryCoreArray[indexPath.row]
        
        cell.textLabel?.text = currentCountry.countryName! + " (" + String(currentCountry.numberOfArtists) + ")"
        
        cell.detailTextLabel?.text = String(currentCountry.latitude) + "," + String(currentCountry.longitude)

        return cell
    }

}
