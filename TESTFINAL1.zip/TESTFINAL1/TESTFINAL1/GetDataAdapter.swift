//
//  GetDataAdapter.swift
//  TESTFINAL1
//
//  Created by User on 9/30/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Data Adapter Class
//To do data request to MusicGraph API

class GetDataAdapter: NSObject {
    
//    Constants and variables to build the right utl call 
    let baseUrl = "http://api.musicgraph.com/api/v2/"
    var searchSection : String = ""
    let searchString = "/search?"
//    MY API KEY
//    adf502e5f87f10e22511e0cf69988826
//    EXAMPLES API KEY
//    c8303e90962e3a5ebd5a1f260a69b138
    let apiKey = "api_key=adf502e5f87f10e22511e0cf69988826"
    let limit = "&limit=100"

    //    ========================================================
    //    MARK: TO GET DATA FOR ARTIST SOCIAL METRICS CLASS
    func getSOCIALMETRICSList(stringToURL : String, completionHandler: (socialMetricsArray: [SocialMetrics])->Void)
    {
        searchSection = "artist/"
        var searchFor : String = ""
        
        searchFor = "/social-urls?"
        
//        Build the right url call for the API
        let url2 = baseUrl+searchSection+stringToURL+searchFor+apiKey
        
//        Create NSURL object
        let url = NSURL(string: url2)!
                
        var socialMetricsArray : [SocialMetrics] = []
        
        var JSONObject : NSDictionary!
        
//        Create NSURLSession object
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // Create data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                // run try catch block
                do {
                    // try to read the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
                    //        setting First entry as Array
                    let resultDict = JSONObject.objectForKey("data") as! NSDictionary
                    
//                    Creating a work instance for SocialMetrics class
                        let socialMetricsObj = SocialMetrics()
                    
//                    Reading JSON object to catch info into the class
                        if let musicbrainz_url = resultDict["musicbrainz_url"] as? String {
                            socialMetricsObj.musicbrainz_url = musicbrainz_url
                        }
                
                        if let facebook_url = resultDict["facebook_url"] as? String {
                            socialMetricsObj.facebook_url = facebook_url
                        }
                        
                        if let allmusic_urlArray = resultDict["allmusic_url"] {
                            if allmusic_urlArray.count > 0
                            {
                                if let allmusic_url = allmusic_urlArray[0] as? String {
                                        socialMetricsObj.allmusic_url = allmusic_url
                                }
                            }
                        }
                    
                        if let bbc_urlArray = resultDict["bbc_url"] {
                            if bbc_urlArray.count > 0
                            {
                                if let bbc_url = bbc_urlArray[0] as? String {
                                    socialMetricsObj.bbc_url = bbc_url
                                }
                            }
                        }
                    
                        if let discogs_urlArray = resultDict["discogs_url"] {
                            if discogs_urlArray.count > 0
                            {
                                if let discogs_url = discogs_urlArray[0] as? String {
                                    socialMetricsObj.discogs_url = discogs_url
                                }
                            }
                        }
                        
                        if let instagram_urlArray = resultDict["instagram_url"] {
                            if instagram_urlArray.count > 0
                            {
                                if let instagram_url = instagram_urlArray[0] as? String {
                                    socialMetricsObj.instagram_url = instagram_url
                                }
                            }
                        }
                        
                        if let lastfm_urlArray = resultDict["lastfm_url"] {
                            if lastfm_urlArray.count > 0
                            {
                                if let lastfm_url = lastfm_urlArray[0] as? String {
                                    socialMetricsObj.lastfm_url = lastfm_url
                                }
                            }
                        }
                        
                        if let official_urlArray = resultDict["official_url"] {
                            if official_urlArray.count > 0
                            {
                                if let official_url = official_urlArray[0] as? String {
                                    socialMetricsObj.official_url = official_url
                                }
                            }
                        }

                        if let spotify_urlArray = resultDict["spotify_url"] {
                            if spotify_urlArray.count > 0
                            {
                                if let spotify_url = spotify_urlArray[0] as? String {
                                    socialMetricsObj.spotify_url = spotify_url
                                }
                            }
                        }
                        
                        if let twitter_urlArray = resultDict["twitter_url"] {
                            if twitter_urlArray.count > 0
                            {
                                if let twitter_url = twitter_urlArray[0] as? String {
                                    socialMetricsObj.twitter_url = twitter_url
                                }
                            }
                        }
                        
                        if let vevo_urlArray = resultDict["vevo_url"] {
                            if vevo_urlArray.count > 0
                            {
                                if let vevo_url = vevo_urlArray[0] as? String {
                                    socialMetricsObj.vevo_url = vevo_url
                                }
                            }
                        }
                        
                        if let wikipedia_urlArray = resultDict["wikipedia_url"] {
                            if wikipedia_urlArray.count > 0
                            {
                                if let wikipedia_url = wikipedia_urlArray[0] as? String {
                                    socialMetricsObj.wikipedia_url = wikipedia_url
                                }
                            }
                        }
                        
                        if let youtube_urlArray = resultDict["youtube_url"] {
                            if youtube_urlArray.count > 0
                            {
                                if let youtube_url = youtube_urlArray[0] as? String {
                                    socialMetricsObj.youtube_url = youtube_url
                                }
                            }
                        }
                    
                        socialMetricsArray.append(socialMetricsObj)
//                    }
                    //                    }
                    
                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            completionHandler(socialMetricsArray: socialMetricsArray)
            
        }
        // excute the data task
        dataTask.resume()

    }


    //    ========================================================
    //    MARK: TO GET DATA FOR TRACK CLASS
    func getTRACKList(stringToURL : String, completionHandler: (trackArray: [Track])->Void)
    {
        
        searchSection = "track/"
        
//        Build the right url call for the API
        let url2 = baseUrl+stringToURL+apiKey+limit
        
//        Create NSURL object
        let url = NSURL(string: url2)!
        
        var trackArray : [Track] = []
        
        var JSONObject : NSDictionary!
        
//        Create NSURLSession object
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                // run try catch block
                do {
                    // try to read the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
                    //        setting First entry as Array
                    let arrayofEntries = JSONObject.objectForKey("data") as! [NSDictionary]
                    
                    //        Runnig trough Array
                    for resultDict in arrayofEntries{
                        
//                        Working instance to catch info from json dictionary
                        let trackObj = Track()
                        
                        if let album_title = resultDict["album_title"] as? String {
                            trackObj.album_title = album_title
                        }
                        
                        if let artist_name = resultDict["artist_name"] as? String {
                            trackObj.artist_name = artist_name
                        }
                        
                        if let duration = resultDict["duration"] as? String {
                            trackObj.duration = duration
                        }
                        
                        if let entity_type = resultDict["entity_type"] as? String {
                            trackObj.entity_type = entity_type
                        }
                        
                        if let id = resultDict["id"] as? String {
                            trackObj.id = id
                        }
                        
                        if let isrc = resultDict["isrc"] as? String {
                            trackObj.isrc = isrc
                        }
                        
                        if let label_name = resultDict["label_name"] as? String {
                            trackObj.label_name = label_name
                        }
                        
                        if let main_genre = resultDict["main_genre"] as? String {
                            trackObj.main_genre = main_genre
                        }
                        
                        if let original_release_year = resultDict["original_release_year"] as? String {
                            trackObj.original_release_year = original_release_year
                        }
                        
                        if let popularity = resultDict["popularity"] as? String {
                            trackObj.popularity = popularity
                        }
                        
                        if let release_year = resultDict["release_year"] as? String {
                            trackObj.release_year = release_year
                        }
                        
                        if let title = resultDict["title"] as? String {
                            trackObj.title = title
                        }
                        
                        if let track_album_id = resultDict["track_album_id"] as? String {
                            trackObj.track_album_id = track_album_id
                        }
                        

                        if let track_album_ref_id = resultDict["track_album_ref_id"] as? String {
                            trackObj.track_album_ref_id = track_album_ref_id
                        }
                        

                        if let track_artist_id = resultDict["track_artist_id"] as? String {
                            trackObj.track_artist_id = track_artist_id
                        }
                        

                        if let track_artist_ref_id = resultDict["track_artist_ref_id"] as? String {
                            trackObj.track_artist_ref_id = track_artist_ref_id
                        }
                        

                        if let track_index = resultDict["track_index"] as? String {
                            trackObj.track_index = track_index
                        }
                        

                        if let track_ref_id = resultDict["track_ref_id"] as? String {
                            trackObj.track_ref_id = track_ref_id
                        }
                        

                        if let track_spotify_id = resultDict["track_spotify_id"] as? String {
                            trackObj.track_spotify_id = track_spotify_id
                        }
                        

                        if let track_youtube_id = resultDict["track_youtube_id"] as? String {
                            trackObj.track_youtube_id = track_youtube_id
                        }
                        
                        trackArray.append(trackObj)
                    }
                            //                    }
                            
                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            
            trackArray.sortInPlace({ $0.track_index < $1.track_index })
            
            completionHandler(trackArray: trackArray)
            
        }
        // excute the data task
        dataTask.resume()
        
        //Change this for every single class
        
        
    }

    

//    ========================================================
//    MARK: TO GET DATA FOR ALBUM CLASS
    func getALBUMList(stringToURL : String, completionHandler: (albumArray: [Album])->Void)
    {
     
        searchSection = "album"
        
        let url2 = baseUrl+searchSection+searchString+apiKey+stringToURL+limit
        
        let url = NSURL(string: url2)!
        
        var albumArray : [Album] = []
        
        var JSONObject : NSDictionary!
        
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                // run try catch block
                do {
                    // try to read the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
                    //        setting First entry as Array
                    let arrayofEntries = JSONObject.objectForKey("data") as! [NSDictionary]
                    
                    //        Runnig trough Array
                    for resultDict in arrayofEntries{
                
                        let albumObj = Album()
                        
                        
                        if let album_artist_id = resultDict["album_artist_id"] as? String {
                            albumObj.album_artist_id = album_artist_id
                        }
                        
                        if let  album_musicbrainz_id = resultDict["album_musicbrainz_id"] as? String {
                            albumObj.album_musicbrainz_id = album_musicbrainz_id
                        }
                        
                        if let  album_ref_id = resultDict["album_ref_id"] as? String {
                            albumObj.album_ref_id = album_ref_id
                        }
                        
                        if let  artist_name = resultDict["artist_name"] as? String {
                            albumObj.artist_name = artist_name
                        }
                        
                        if let  decade = resultDict["decade"] as? String {
                            albumObj.decade = decade
                        }
                        
                        if let  entity_type = resultDict["entity_type"] as? String {
                            albumObj.entity_type = entity_type
                        }
                        
                        if let  id = resultDict["id"] as? String {
                            albumObj.id = id
                        }
                        
                        if let  label_name = resultDict["label_name"] as? String {
                            albumObj.label_name = label_name
                        }
                        
                        if let  main_genre = resultDict["main_genre"] as? String {
                            albumObj.main_genre = main_genre
                        }
                        
                        if let  number_of_tracks = resultDict["number_of_tracks"] as? String {
                            albumObj.number_of_tracks = number_of_tracks
                        }
                        
                        if let  popularity = resultDict["popularity"] as? String {
                            albumObj.popularity = popularity
                        }
                        
                        if let  product_form = resultDict["product_form"] as? String {
                            albumObj.product_form = product_form
                        }
                        
                        if let  release_date = resultDict["release_date"] as? String {
                            albumObj.release_date = release_date
                        }
                        
                        if let  release_year = resultDict["release_year"] as? Int {
                            albumObj.release_year = String(release_year)
                        }
                        
                        if let  title = resultDict["title"] as? String {
                            albumObj.title = title
                        }
                        

                        albumArray.append(albumObj)
                    }
                    //                    }
                    
                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            
            albumArray.sortInPlace({ $0.release_year > $1.release_year })
            
            completionHandler(albumArray: albumArray)
            
        }
        // excute the data task
        dataTask.resume()
        
        //Change this for every single class
        
        
    }



    //=========================================================
    //    MARK: TO GET DATA FOR ARTIST CLASS
    func getARTISTList(stringToURL : String, completionHandler: (artistArray: [Artist], countryArray: [String])->Void)
    {
        
        searchSection = "artist"
        
        let url2 = baseUrl+searchSection+searchString+apiKey+"&"+stringToURL+limit
        
        let url = NSURL(string: url2)!
        
        var artistArray : [Artist] = []
        var countryArray : [String] = []
        var JSONObject : NSDictionary!
        
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                // run try catch block
                do {
                    // try to read the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
                    //        setting First entry as Array
                    let arrayofEntries = JSONObject.objectForKey("data") as! [NSDictionary]
                    
                    //        Runnig trough Array
                    for resultDict in arrayofEntries{

                        //Declaring the work object of Class Artist
                        let artistObj = Artist()
                            
                            if let artist_ref_id = resultDict["artist_ref_id"] as? String {
                                artistObj.artist_ref_id = artist_ref_id
                            }
                            
                            if let country_of_origin = resultDict["country_of_origin"] as? String {
                                artistObj.country_of_origin = country_of_origin
                            }
                            
                            if let decade = resultDict["decade"] as? String {
                                artistObj.decade = decade
                            }
                            
                            if let entity_type = resultDict["entity_type"] as? String {
                                artistObj.entity_type = entity_type
                            }
                            
                            if let gender = resultDict["gender"] as? String {
                                artistObj.gender = gender
                            }
                            
                            if let id = resultDict["id"] as? String {
                                artistObj.id = id
                            }
                            
                            if let main_genre = resultDict["main_genre"] as? String {
                                artistObj.main_genre = main_genre
                            }
                            
                            if let musicbrainz_id = resultDict["musicbrainz_id"] as? String {
                                artistObj.musicbrainz_id = musicbrainz_id
                            }
                            
                            if let musicbrainz_image_url = resultDict["musicbrainz_image_url"] as? String {
                                artistObj.musicbrainz_image_url = musicbrainz_image_url
                            }
                            
                            if let name = resultDict["name"] as? String {
                                artistObj.name = name
                            }
                            
                            if let sort_name = resultDict["sort_name"] as? String {
                                artistObj.sort_name = sort_name
                            }
                            
                            if let spotify_id = resultDict["spotify_id"] as? String {
                                artistObj.spotify_id = spotify_id
                            }
                            
                            if let youtube_id = resultDict["youtube_id"] as? String {
                                artistObj.youtube_id = youtube_id
                            }
                        
//                        Appending the new object to the Array
                            artistArray.append(artistObj)
                        
//                        Appending new country to countryArray
                            if artistObj.country_of_origin != "" {
                                countryArray.append(artistObj.country_of_origin)
                            }
                        }
//                    }

                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            
//            Sorting Artist Array by Name
            artistArray.sortInPlace({ $0.name < $1.name })
            
            completionHandler(artistArray: artistArray, countryArray: countryArray)
            
        }
        // excute the data task
        dataTask.resume()
        
        //Change this for every single class
    }

    
//    MARK: TO DOWNLOAD IMAGES FOR ARTISTS AND ALBUMS
    
    func downloadImage(imageURL: String, completionHandler: (downloadedImage: UIImage)->Void){
        
//        Task and Session variables
        var downloadTask : NSURLSessionDownloadTask = NSURLSessionDownloadTask()
        let downloadSession : NSURLSession = NSURLSession.sharedSession()
        
//        Creating NSURL object
        let url = NSURL(string: imageURL)!
        
//        Creating Session and Task to downloag image
        downloadTask = downloadSession.downloadTaskWithURL(url, completionHandler: { (location: NSURL?, response: NSURLResponse?, error: NSError?) -> Void in
          
//            Set download image to an UIImage object
            let downloadedImage : UIImage = UIImage(data: NSData(contentsOfURL: location!)!)!
            
            completionHandler(downloadedImage: downloadedImage)
            
        })
        downloadTask.resume()
    }

} //CLASS