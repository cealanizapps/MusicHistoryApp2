//
//  Download.swift
//  TESTFINAL1
//
//  Created by User on 10/12/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import Foundation

//Download Class

class Download: NSObject {
    
    var url: String
    var isDownloading = false
    var progress: Float = 0.0
    
    var downloadTask: NSURLSessionDownloadTask?
    var resumeData: NSData?
    
    init(url: String) {
        self.url = url
    }
}
