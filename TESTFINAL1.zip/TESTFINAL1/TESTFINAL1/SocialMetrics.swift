//
//  SocialMetrics.swift
//  TESTFINAL1
//
//  Created by User on 9/29/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Social Metrics Class

class SocialMetrics: NSObject {
    
    var spotifyUrl : String = ""
    var spotifyPopularity : String = ""
    var spotifyFollowers : String = ""
    var vevoUrl : String = ""
    var vevoViewsLastMonth : String = ""
    var vevoViewsLastDay : String = ""
    var vevoViewsTotal : String = ""
    var vevoViewsLastWeek : String = ""
    var vevoName : String = ""
    var twitterFollowing : String = ""
    var twitterTweets : String = ""
    var twitterFollowers : String = ""
    var twitterUrl : String = ""
    var facebookUrl : String = ""
    var facebookLikes : String = ""
    var lastfmUrl : String = ""
    var lastfmListeners : String = ""
    var lastfmPlaycount : String = ""
    var lastfmId : String = ""
    var instagramFollowing : String = ""
    var instagramUrl : String = ""
    var media_countFollowers : String = ""
 
    //Changing request to API
    
    var allmusic_url : String = ""
    var oficial_url : String = ""
    var bbc_url : String = ""
    var discogs_url : String = ""
    var facebook_url : String = ""
    var instagram_url : String = ""
    var lastfm_url : String = ""
    var musicbrainz_url : String = ""
    var official_url : String = ""
    var spotify_url : String = ""
    var twitter_url : String = ""
    var vevo_url : String = ""
    var wikipedia_url : String = ""
    var youtube_url : String = ""
    
   
}
