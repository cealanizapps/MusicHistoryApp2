//
//  ArtistCore.swift
//  TESTFINAL1
//
//  Created by User on 10/12/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import Foundation
import CoreData


class ArtistCore: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
