//
//  GetDataAdapterSpotify.swift
//  TESTFINAL1
//
//  Created by User on 10/7/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Data Adapter Class
//To do data request to Spotify API

class GetDataAdapterSpotify: NSObject {
    
//    Setting variables to build the right url and make request to Spotify API
    let baseUrl = "https://api.spotify.com/v1/"
    var searchSection : String = ""
    let searchString = "/albums"
    
    let apiKey = "api_key=adf502e5f87f10e22511e0cf69988826&"
    let limit = "&limit=100"

    //    ========================================================
    //    MARK: TO GET DATA FOR TRACK CLASS
    func getTRACKSpotifyList(albumID : String, completionHandler: (trackArray: [[Track]], discLabel: String, discReleaseDate: String)->Void)
    {
        
        searchSection = "albums/"
        
//        Build the rigt URL
        
        let url2 = baseUrl+searchSection+albumID
        
        let url = NSURL(string: url2)!
        
//        Creating Array of Arrays of tracks to manage different Discs on the same album
        var trackArray : [[Track]] = [[]]
        
//        Creating an Array of Tracks to parse JSON object initially and then separate it on different Discs
        var trackArrayParse : [Track] = []
        
        var JSONObject : NSDictionary!
        
        var discLabelReturn : String!
        var discReleaseDateReturn : String!
        
//        Creating NSURLSession object
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // Creting data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                
                do {
                    // Reading the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
//                    Album label
                    if let disc_label = JSONObject["label"] as? String {
                        discLabelReturn = disc_label
                    }
                    
//                    Album release_date
                    if let disc_release_date = JSONObject["release_date"] as? String {
                        discReleaseDateReturn = disc_release_date
                    }

                    //        Runnig trough Array of Tracks
                    let arrayofTracks = JSONObject.objectForKey("tracks")?.objectForKey("items") as! [NSDictionary]
                        
                        for track in arrayofTracks
                        {
                        
                            let trackObj = Track()
                        
                            if let disc_number = track["disc_number"] as? Int {
                                trackObj.disc_number = disc_number
                            }

                            if let duration_ms = track["duration_ms"] as? Int {
                                trackObj.duration_ms = duration_ms
                            }

                            if let explicit = track["explicit"] as? Bool {
                                trackObj.explicit = explicit
                            }

                            if let href = track["href"] as? String {
                                trackObj.href = href
                            }

                            if let spotifyId = track["id"] as? String {
                                trackObj.spotifyId = spotifyId
                            }

                            if let name = track["name"] as? String {
                                trackObj.name = name
                            }

                            if let preview_url = track["preview_url"] as? String {
                                trackObj.preview_url = preview_url
                            }

                            if let track_number = track["track_number"] as? Int {
                                trackObj.track_number = track_number
                            }
                        
                            if let spotifyUrl = track["external_urls"]!.objectForKey("spotify") as? String {
                                    trackObj.spotifyUrl = spotifyUrl
                             }
                            
                            trackArrayParse.append(trackObj)
                        }
                    
                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            
//            Sort the Initial Array for Disc Number and Track Numbers
            trackArrayParse.sortInPlace{
                if $0.disc_number != $1.disc_number {
                    return $0.disc_number < $1.disc_number
                }
                else {
                    //disc numbers are the same, so now sort by track number
                    return $0.track_number < $1.track_number
                }
            }
            
//            Run trough Initial Array to split in an Array of Arrays
//            Separated by DiscNumber
            var indexArrays = 0
            var discNum = trackArrayParse[0].disc_number
            let firtDisc = trackArrayParse[0]
            trackArray[indexArrays].append(firtDisc)
            
//            Run trough initial Array to split on different arrays by album
            for index in 1...trackArrayParse.count - 1
            {
//                Checking if is the same dis number
                if discNum != trackArrayParse[index].disc_number
                {
                    indexArrays += 1
                    discNum = trackArrayParse[index].disc_number
                    trackArray.append([])
                }
                let track2Add = trackArrayParse[index]
                trackArray[indexArrays].append(track2Add)
            }
            
            completionHandler(trackArray: trackArray, discLabel: discLabelReturn, discReleaseDate: discReleaseDateReturn)
            
        }
        
        dataTask.resume()
        
    }
    
    
    
    //    ========================================================
    //    MARK: TO GET DATA FOR ALBUM CLASS FOR A GIVEN ARTIST
    func getALBUMSpotifyList(artistID : String, completionHandler: (albumArray: [Album])->Void)
    {
        
        searchSection = "artists/"
        
        let complimentString = "/albums?offset=0&limit=50&album_type=album"
        
//        Build the rigth url
        let url2 = baseUrl+searchSection+artistID+complimentString
        
        let url = NSURL(string: url2)!
        
        var albumArray : [Album] = []
        
        var JSONObject : NSDictionary!
        
//        Create NSURLSession object
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // Create data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                do {
                    // try to read the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
                    //        setting First entry as Array
                    let arrayofEntries = JSONObject.objectForKey("items") as! [NSDictionary]
                    
                    //        Runnig trough Array
                    for resultDict in arrayofEntries
                    {
                        
                        let albumObj = Album()
                        
                        if let title = resultDict["name"] as? String {
                            albumObj.title = title
                        }
                        
                        if let label = resultDict["label"] as? String {
                            albumObj.label_name = label
                        }

                        if let spotify_id = resultDict["id"] as? String {
                            albumObj.spotify_id = spotify_id
                        }
                        
                        if let spotifyUrl = resultDict["external_urls"]!.objectForKey("spotify") as? String
                        {
                            albumObj.spotify_url = spotifyUrl
                        }
                        
                        var imagesArray : [CustomImage] = []
                        
                        // Getting Cover Images Array for the Album
                        let arrayofImages = resultDict["images"] as! [NSDictionary]
                        if arrayofImages.count > 0
                        {
                            for iImage in 0...arrayofImages.count-1{
                                
                                let image = CustomImage()
                                
                                if let height = arrayofImages[iImage]["height"] as? Int {
                                    image.height = height
                                }
                                
                                if let width = arrayofImages[iImage]["width"] as? Int {
                                    image.width = width
                                }
                                
                                if let url = arrayofImages[iImage]["url"] as? String {
                                    image.url = url
                                }
                                
                                imagesArray.append(image)
                            }
                        }
                        
//                        Set the array to the Album object
                        albumObj.imageArray = imagesArray
                        
                        albumArray.append(albumObj)
                    }
                    //                    }
                    
                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            

            completionHandler(albumArray: albumArray)
            
        }
        
        dataTask.resume()
        
    }
    
    
    
    //=========================================================
    //    MARK: TO GET IMAGES DATA FOR ARTIST CLASS
    func getARTISTSpootifyImagesURL(stringToURL : String, completionHandler: (imageArray: [CustomImage])->Void)
    {
        
        searchSection = "artists/"
        
//        Create rigth url
        let url2 = baseUrl+searchSection+stringToURL
        
        let url = NSURL(string: url2)!
        
        var imageArray : [CustomImage] = []
        var JSONObject : NSDictionary!
        
//        Create NSURLSession object
        let APISession: NSURLSession = NSURLSession.sharedSession()
        // Create data task
        let dataTask = APISession.dataTaskWithURL(url) { (data: NSData?, response: NSURLResponse?, error: NSError?) in
            // if error display the error message
            if ( (error) != nil) {
                print(error?.localizedDescription)
            } else {
                
                do {
                    // try to read the data from the url
                    JSONObject = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary
                    
                    //        setting First entry as Array
                    // Images
                    if let errorMsg = JSONObject["error"]?.objectForKey("message") as? String {
                        print(errorMsg)
                    }
                    else
                    {
                        let arrayofImages = JSONObject["images"] as! [NSDictionary]
                        if arrayofImages.count > 0
                        {
                            for iImage in 0...arrayofImages.count-1{
                                
                                let image = CustomImage()
                                
                                if let height = arrayofImages[iImage]["height"] as? Int {
                                    image.height = height
                                }
                                
                                if let width = arrayofImages[iImage]["width"] as? Int {
                                    image.height = width
                                }
                                
                                if let url = arrayofImages[iImage]["url"] as? String {
                                    image.url = url
                                }
                                
                                imageArray.append(image)
                            }
                        }
                    }
                    
                } catch {
                    print("there was an error with the JSON Object")
                }
            }
            
            completionHandler(imageArray: imageArray)
            
        }
        // excute the data task
        dataTask.resume()
        
    }
    
    
    //    MARK: TO DOWNLOAD IMAGES FOR ARTISTS AND ALBUMS USING THE URL GIVEN
    
    func downloadImage(imageURL: String, completionHandler: (downloadedImage: UIImage)->Void){
        
//        Creating NSURLSession y DownloadTask Objects
        var downloadTask : NSURLSessionDownloadTask = NSURLSessionDownloadTask()
        let downloadSession : NSURLSession = NSURLSession.sharedSession()

//        Creating NSURL object
        let url = NSURL(string: imageURL)!
        
//        Creating Session and Task to downloag image
        downloadTask = downloadSession.downloadTaskWithURL(url, completionHandler: { (location: NSURL?, response: NSURLResponse?, error: NSError?) -> Void in

//            Set download image to an UIImage object
            let downloadedImage : UIImage = UIImage(data: NSData(contentsOfURL: location!)!)!
            
            completionHandler(downloadedImage: downloadedImage)
            
        })
        downloadTask.resume()
    }
    

}  //CLASS
