//
//  genreTableViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/2/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

//This UITableViewController is to show Genres of Music that User can choose
//in order to see all the artists that play music of the choosen genre

import UIKit

class genreTableViewController2: UITableViewController {
    
//    Data to populate the array
//    MusicGraph API has this genres already set to manage searches
    var genreArray : [String] = ["Alternative/Indie",
                                 "Blues",
                                 "Cast Recordings/Cabaret",
                                 "Christian/Gospel",
                                 "Children's",
                                 "Classical/Opera",
                                 "Comedy/Spoken Word",
                                 "Country",
                                 "Electronica/Dance",
                                 "Folk",
                                 "Instrumental",
                                 "Jazz",
                                 "Latin",
                                 "New Age",
                                 "Pop",
                                 "Rap/Hip Hop",
                                 "Reggae/Ska",
                                 "Rock",
                                 "Seasonal",
                                 "Soul/R&B",
                                 "Soundtracks",
                                 "Vocals",
                                 "World"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genreArray.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) 
        
        let Value = genreArray[indexPath.row]
        
        cell.textLabel?.text = Value
        
        return cell
    }
    
    
    // MARK: - Segues
//    Preparing info to send to Artist ViewController
//    In order to make the search by genre
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
//        For this segue we send the genre selected
        if segue.identifier == "segueGenreArtist2" {
            
            if let indexPath = tableView.indexPathForSelectedRow {
                
                if let destination = segue.destinationViewController as? artistMasterTableViewController {
                    
                    let genre = genreArray[indexPath.row]
                    var genre2 : String! = ""
                    
                    genre2 = genre.stringByReplacingOccurrencesOfString(" ", withString: "+")
                    
                    destination.genreToSearch = "genre=" + genre2
                    destination.genre = genre
                    
                }
            }
        }
    }
    
}
