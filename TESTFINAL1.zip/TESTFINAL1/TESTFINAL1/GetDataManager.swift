//
//  GetDataManager.swift
//  TESTFINAL1
//
//  Created by User on 9/30/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Data Manager class
//To manage Data Request

class GetDataManager: NSObject {

//    Instance for GetDataManager singleton class
    static let sharedInstance = GetDataManager()
    private override init() {super.init()}
    
    //    Instance for GetDataAdapter singleton class
    private let getDataAdapter = GetDataAdapter()
    //    Instance for GetDataAdapterSpotify singleton class
    private let getDataAdapterSpotify = GetDataAdapterSpotify()
    
//    Arrays to use in functions init
    var artistArray : [Artist] = []
    var albumArray : [Album] = []
    var trackArray : [[Track]] = [[]]
    var socialMetricsArray : [SocialMetrics] = []
    
    var countryOccurArray : [String:Int] = [:]
    
    
//    MARK: To GET the ARTIST List
    func getARTISTList(stringToCompleteURL : String, completionHandler : ()->Void) //-> [Artist]
    {
//        Call for Artist List function on Adapter
        getDataAdapter.getARTISTList(stringToCompleteURL) { (artistArray, countryArray) in

            
        //Clear the current artist array and set the artistArray to the new one from the service
        self.artistArray.removeAll()
        self.artistArray = artistArray

//        call for function that takes repeated items off and generates a new array of countries
        self.countryOccurArray = self.runOccurArray(countryArray)

//            Flag to validate the last item
            var lastItem : Bool = false
            
//            Run through Artist array for checking country
            for artistIndex in 0...artistArray.count-1
            {
                //bool = true if it's the last item in the array
                if artistIndex  == artistArray.count-1
                {
                    lastItem = true
                }
                
//                Calling for more artist's image url
                self.getDataAdapterSpotify.getARTISTSpootifyImagesURL(artistArray[artistIndex].spotify_id, completionHandler: { (imageArray) in
//                    Validate if images array is not emtpy
                        if imageArray.count > 0
                        {
//                          Set imagearray to artist
                            artistArray[artistIndex].imageArray = imageArray
                            if (lastItem == true)
                            {
                                completionHandler()
                            }
                        }
                })
                
            }
        }
        
    }

    
    // MARK : Function that takes repeated items off and generates a new array of countries
    func runOccurArray(countryArray: [String]) -> [String:Int] {
        
        var countryOccur: [String:Int] = [:]
        
        for country in countryArray
        {
            countryOccur[country] = (countryOccur[country] ?? 0) + 1
        }
        
        return countryOccur
    }

//    MARK: To GET the ALBUM List by ARTIST
    func getALBUMList(stringToCompleteURL : String, completionHandler : ()->Void)
    {
        
//        Call function that gets Album list for a given artist
        getDataAdapter.getALBUMList(stringToCompleteURL) { (albumArray) in
            
            //Clear the current artist array and set the artistArray to the new one from the service
            self.albumArray.removeAll()
            self.albumArray = albumArray
            
            //ViewController's completion handler
            completionHandler()
        }
    }
    
    //    MARK: To GET the TRACK List
    func getTRACKList(stringToCompleteURL : String, completionHandler : ()->Void)
    {
        
//        Call function that gets Track list for a given album
        getDataAdapter.getTRACKList(stringToCompleteURL) { (trackArray) in
            
            //Clear the current artist array and set the artistArray to the new one from the service
            self.trackArray.removeAll()
            
            //ViewController's completion handler
            completionHandler()
        }
        
    }
    
    //    MARK: To GET the Social Metrics List
    func getSOCIALMETRICSList(stringToCompleteURL : String, completionHandler : () -> Void) {
        
//        call function that gets Social metrics list for a given artist
        getDataAdapter.getSOCIALMETRICSList(stringToCompleteURL) { (socialMetricsArray) in
            
            //Clear the current artist array and set the artistArray to the new one from the service
            self.socialMetricsArray.removeAll()
            self.socialMetricsArray = socialMetricsArray
            
            //ViewController's completion handler
            completionHandler()
        }
        
    }
    
//    *******************************************
//    ***** S P O T I F Y ** D A T A ************
//    *******************************************
    
    //    MARK: For Spotify download albums
    //    MARK: To GET the ALBUM List by ARTIST
    func getTRACKSpotifyList(albumID : String, arrayIndex: Int, completionHandler : ()->Void) //-> [Album]
    {
//        function that gets Track list for a given Album from Spotify
        getDataAdapterSpotify.getTRACKSpotifyList(albumID) { (trackArray, discLabel, discReleaseDate) in
            
//            Set extra info for the given album
            self.albumArray[arrayIndex].label_name = discLabel
            self.albumArray[arrayIndex].release_date = discReleaseDate
            let substrIndex = discReleaseDate.startIndex.advancedBy(4)
            self.albumArray[arrayIndex].release_year = discReleaseDate.substringToIndex(substrIndex)
            
            //Clear the current artist array and set the artistArray to the new one from the service
            self.trackArray.removeAll()
            self.trackArray = trackArray
            
            //ViewController's completion handler
            completionHandler()
        }
    }
    
    
//    MARK: For Spotify download albums
//    MARK: To GET the ALBUM List by ARTIST
    func getALBUMSpotifyList(artistID : String, completionHandler : ()->Void) //-> [Album]
    {

        //        function that gets Album list for a given Artist from Spotify
        getDataAdapterSpotify.getALBUMSpotifyList(artistID) { (albumArray) in
            
            //Clear the current artist array and set the artistArray to the new one from the service
            self.albumArray.removeAll()
            self.albumArray = albumArray

            //ViewController's completion handler
            completionHandler()
        }
    }

    //    MARK: For Spotify Artist Image URL
    func getARTISTSpootifyImagesURL(artistID : String, arrayIndex: Int, completionHandler : ()->Void)
    {
        
        //        function that gets images' url list for a given Artist from Spotify
        getDataAdapterSpotify.getARTISTSpootifyImagesURL(artistID) { (imageArray) in
            
            //Clear the current artist array and set the artistArray to the new one from the service
            self.artistArray[arrayIndex].imageArray.removeAll()
            self.artistArray[arrayIndex].imageArray = imageArray
            
            //ViewController's completion handler
            completionHandler()
        }
    }
    

    //    MARK: To Download Artist Image
    func downloadArtistImage(index: Int, completionHandler: ()->Void){
        
        //        function that gets image for a given artist using the images array
//        and sets it to the right property in the artist object
        getDataAdapter.downloadImage(self.artistArray[index].imageArray[1].url) { (downloadedImage) in
            self.artistArray[index].artistImage = downloadedImage
            completionHandler()
        }
    }
    
    
//    MARK: To Download Album Cover Image
    func downloadAlbumImage(index: Int, completionHandler: ()->Void){
    
        //        function that gets cover album image for a given album
//        and sets it to the right property in the album object
        getDataAdapter.downloadImage(self.albumArray[index].imageArray[1].url) { (downloadedImage) in
            self.albumArray[index].albumCoverImage = downloadedImage
            completionHandler()
        }
    }
    
} //CLASS
