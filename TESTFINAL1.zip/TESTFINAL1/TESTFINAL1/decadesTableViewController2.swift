//
//  decadesTableViewController2.swift
//  TESTFINAL1
//
//  Created by User on 10/10/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

//This UITableViewController is to show Decades in History of Music that User can choose
//in order to see all the artists that play music of the choosen decade

import UIKit

class decadesTableViewController2: UITableViewController {

    //    Data to populate the array
    //    MusicGraph API has this decades already set to manage searches

    var decadesArray : [String] = ["1890s",
                                   "1900s",
                                   "1910s",
                                   "1920s",
                                   "1930s",
                                   "1940s",
                                   "1950s",
                                   "1960s",
                                   "1970s",
                                   "1980s",
                                   "1990s",
                                   "2000s",
                                   "2010s"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return decadesArray.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
        let Value = decadesArray[indexPath.row]
        
        cell.textLabel?.text = Value
        // Configure the cell...
        
        return cell
    }
    
    // MARK: - Segues
    //    Preparing info to send to Artist ViewController
    //    In order to make the search by decade

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
//        For this segue we send the decade selected
        if segue.identifier == "segueDecadeArtist2" {
            if let indexPath = tableView.indexPathForSelectedRow {
                
                if let destination = segue.destinationViewController as? artistMasterTableViewController {
                    
                    let decades = decadesArray[indexPath.row]
                    destination.decadeToSearch = "decade="+decades
                    destination.decades = decades
                    
                }
            }
        }
    }
    
}
