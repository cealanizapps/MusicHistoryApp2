//
//  LocationsAdapter.swift
//  TESTFINAL1
//
//  Created by User on 10/13/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import MapKit

//MARK : Class used to get Country Coordinate
class LocationsAdapter: NSObject {
    
    let baseUrl = "https://maps.googleapis.com/maps/api/geocode/json?&address="
    let apikey = "&key=AIzaSyBQpWaWPIbCixOguq7l_9ZKgQbXGbToSWs"
    
//    MARK : Function to get country coordinates
//    Using country name, returning latitude, longitude and place_id
    func getCountryCoordinates(country: String, completionHandler: (latitude: Double, longitude: Double, place_id: String) -> Void)
    {
        var countryUsing : String!
//        Cleaning country name string when using more than one value
        if country.containsString("/"){
            let index = country.characters.indexOf("/")
            countryUsing = country.substringToIndex(index!)
        }
        else {
            countryUsing = country
        }
    
//        Substitute spaces for "+"
        let countryNoSPaces = countryUsing.stringByReplacingOccurrencesOfString(" ", withString: "+")
        
//        Build the rigth url
        let url2 = baseUrl+countryNoSPaces+apikey
        
        let url = NSURL(string: url2)!
        
//        Create NSData Object
        let data = NSData(contentsOfURL: url)
        
        var latitudeVar : Double!
        var longitudeVar : Double!
        var place_idVar : String!
        
//        Creting a JSON object to parse
        let json = try! NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments) as! NSDictionary

//        Check if data retrieval was succesful
        if (json["status"] as? String)! == "OK"
        {
//        Parsing JSON result and get coordinate
            if let results = json["results"] as? [NSDictionary] {
                for resultDict in results {
                    
                    if let geometry = resultDict["geometry"] as? NSDictionary {
                        if let location = geometry["location"] as? NSDictionary {
                            latitudeVar = location["lat"] as! Double
                            longitudeVar = location["lng"] as! Double
                        }
                    }
                    
                    place_idVar = resultDict["place_id"] as! String
                    
                }
            }
            
            completionHandler(latitude: latitudeVar, longitude: longitudeVar, place_id: place_idVar)
        }
    }
    
}
