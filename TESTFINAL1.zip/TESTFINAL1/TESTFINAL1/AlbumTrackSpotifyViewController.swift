//
//  AlbumTrackViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/9/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import Social
import Accounts
import MediaPlayer

//controller to show album details
//Show album's tracks
//Play tracks' preview

class AlbumTrackSpotifyViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var artistImageView: UIImageView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var albumNameLabel: UILabel!
    
    @IBOutlet weak var artistNameLabel: UILabel!
    
    @IBOutlet weak var releaseYearLabel: UILabel!
    
    @IBOutlet weak var numberOfSongsLabel: UILabel!
    
    @IBOutlet weak var labelLabel: UILabel!
    
    var artistSpotifyID : String!
    var albumSpotifyID : String!
    var albumArrayIndex : Int!
    var artistName : String!
    
    //    Declaration for Managers Instances
    let getDataManager = GetDataManager.sharedInstance
    
    var albumArray : [Album]!
    
    var discArray : [Int:Int] = [:]
    
    
//    Getting Track data
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getDataManager.getTRACKSpotifyList(albumSpotifyID, arrayIndex: albumArrayIndex, completionHandler: {
                dispatch_async(dispatch_get_main_queue()) {
                    
//                    self.DiscSeparator()
                    self.tableView.reloadData()
                    
                }
            })
        
//        album's Details
        artistImageView.image = getDataManager.albumArray[albumArrayIndex].albumCoverImage
        
        albumNameLabel.text = getDataManager.albumArray[albumArrayIndex].title
        artistNameLabel.text = artistName
        releaseYearLabel.text = getDataManager.albumArray[albumArrayIndex].release_year
        labelLabel.text = getDataManager.albumArray[albumArrayIndex].label_name
        
        var trackCount : Int! = 0
        for trackArr in getDataManager.trackArray
        {
            trackCount = trackCount + trackArr.count
        }
        
        numberOfSongsLabel.text = String(trackCount)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
//        return 1
        return getDataManager.trackArray.count
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        let discNumber = String(getDataManager.trackArray[section][0].disc_number)
        let sectionName = "Disc " + String(section + 1)
        return sectionName
    }
    

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionReturn = getDataManager.trackArray[section].count
        
        return sectionReturn
    }
    
//    Setting Track details on cell
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as! TrackCell
        
        let currentTrack = getDataManager.trackArray[indexPath.section][indexPath.row]
        
        cell.trackTitle.text = String(currentTrack.track_number) + " - " + currentTrack.name
        
//        Get Duration from milliseconds to minutes and seconds
        let milliseconds = currentTrack.duration_ms
        var seconds = milliseconds / 1000
        var minutes = seconds / 60
        let hours = minutes / 60
        seconds %= 60
        minutes %= 60
        
        var secondsString : String!
        
        if seconds < 10
        {
           secondsString = "0" + String(seconds)
        }
        else
        {
            secondsString = String(seconds)
        }
        
        var minutesString : String!
        
        if minutes < 10
        {
            minutesString = "0" + String(minutes)
        }
        else
        {
            minutesString = String(minutes)
        }
        
        var hoursString : String! = ""
        
        if hours > 0
        {
            hoursString = String(minutes)+":"
        }
        
        cell.trackTime.text = hoursString+minutesString+":"+secondsString

        return cell
        
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let currentTrack = getDataManager.trackArray[indexPath.section][indexPath.row]
        
        if let urlString = currentTrack.preview_url as? String
        {
            let url = NSURL(string: urlString)
            
            let moviePlayer:MPMoviePlayerViewController! = MPMoviePlayerViewController(contentURL: url)
            presentMoviePlayerViewControllerAnimated(moviePlayer)
        }

    }
    
//    MARK : SOCIAL MEDIA
    
//    Buttons to share on social media
    @IBOutlet weak var btnPostFacebook: UIButton!
    
    @IBOutlet weak var btnPostTwitter: UIButton!
    
    //Button to post in Twitter
    @IBAction func PostTwitter(sender: UIButton) {
        //        Open an instance of ACAccountStore Class with identifier for twitter
        let account = ACAccountStore()
        let accountType = account.accountTypeWithAccountTypeIdentifier(
            ACAccountTypeIdentifierTwitter)
        
        //        Opening a request to Twitter to post
        account.requestAccessToAccountsWithType(accountType, options: nil,
                                                completion: {(success: Bool, error: NSError!) -> Void in
                                                    
            //            If the request succeeded
            if success {
                //                Get the array of accounts, configured on the device
                let arrayOfAccounts = account.accountsWithAccountType(accountType)
                
                //                runnning trough the array of accounts
                if arrayOfAccounts.count > 0 {
                    
                    //                    Getting the last element of the array of accounts
                    let twitterAccount = arrayOfAccounts.last as! ACAccount
                    
                    //                  Creating a Dictionary for the message
                    var message = Dictionary<String, AnyObject>()
                    
                    message["status"] = "I'd like to share this Album with all of you " + self.getDataManager.albumArray[self.albumArrayIndex].title + " " + self.getDataManager.albumArray[self.albumArrayIndex].spotify_url
                    
                    //                    Opening a SLRequest based on the NSURL object for twitter
                    let requestURL = NSURL(string: "https://api.twitter.com/1.1/statuses/update.json")
                    
                    let postRequest = SLRequest(forServiceType: SLServiceTypeTwitter, requestMethod: SLRequestMethod.POST, URL: requestURL, parameters: message)
                    
                    postRequest.account = twitterAccount
                    
                    postRequest.performRequestWithHandler({
                        (responseData: NSData!, urlResponse: NSHTTPURLResponse!, error: NSError!) -> Void in
                        if let err = error {
                            print("Error : \(err.localizedDescription)")
                        }
                        
                        print("Twitter HTTP response \(urlResponse.statusCode)")
                    })
                }
            }
        })
        
    }
    
//    Button to post on facebook
    @IBAction func PostFacebook(sender: UIButton) {
        
        //        Open an instance of ACAccountStore Class with identifier for Facebook
        
        let accountStore = ACAccountStore()
        let accountType = accountStore.accountTypeWithAccountTypeIdentifier(ACAccountTypeIdentifierFacebook)
        
        //        We have to register the app on Facebook in order to get the App ID Key and use it in posting options
//        1191696210893298
//        868888823245359
        let postingOptions = [ACFacebookAppIdKey: "868888823245359",
                              ACFacebookPermissionsKey: ["public_profile", "email"],
                              ACFacebookAudienceKey: ACFacebookAudienceEveryone]
        
        //        Opening the request to Facebook to use "public_profile" and "email" key
        accountStore.requestAccessToAccountsWithType(accountType, options: postingOptions as [NSObject : AnyObject]) {
            success, error in
            if success {
                
                //        Opening the request to Facebook to use "publish_actions" key
                let options = [ACFacebookAppIdKey: "868888823245359", ACFacebookPermissionsKey: ["publish_actions"], ACFacebookAudienceKey: ACFacebookAudienceFriends]
                
                accountStore.requestAccessToAccountsWithType(accountType, options: options as [NSObject : AnyObject]) {
                    success, error in
                    if success {
                        
                        // Got the Array of Facebook accounts on the device
                        var accountsArray = accountStore.accountsWithAccountType(accountType)
                        
                        // Run trough the array
                        if accountsArray.count > 0 {
                            let facebookAccount = accountsArray[0] as! ACAccount
                            
                            // Establishing Dictionary of parmeters, including message
                            var parameters = Dictionary<String, AnyObject>()
                            
                            parameters["access_token"] = facebookAccount.credential.oauthToken
                            
                            parameters["message"] = "I'd like to share this Album with all of you " + self.getDataManager.albumArray[self.albumArrayIndex].title + " " + self.getDataManager.albumArray[self.albumArrayIndex].spotify_url

                            // Making request to POST to facebook
                            let feedURL = NSURL(string: "https://graph.facebook.com/me/feed")
                            
                            let postRequest = SLRequest(forServiceType: SLServiceTypeFacebook, requestMethod: SLRequestMethod.POST, URL: feedURL, parameters: parameters)
                            
                            postRequest.performRequestWithHandler(
                                {(responseData: NSData!, urlResponse: NSHTTPURLResponse!, error: NSError!) -> Void in
                                    
                                    print("Facebook HTTP response \(urlResponse.statusCode)")
                            })
                        }
                    }
                    else {
                        print("Access denied")
                        
                        print(error.localizedDescription)
                    }
                }
            }
            else {
                print("Access denied")
                print(error.localizedDescription)
            }
        }
    }

    
    
} //CLASS
