//
//  Album.swift
//  TESTFINAL1
//
//  Created by User on 9/29/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Album Class

class Album: NSObject {

    var album_artist_id : String = ""
    var album_musicbrainz_id : String = ""
    var album_ref_id : String = ""
    var artist_name : String = ""
    var decade : String = ""
    var entity_type : String = ""
    var id : String = ""
//    var label_name : String = ""
    var main_genre : String = ""
    var number_of_tracks : String = ""
    var popularity : String = ""
    var product_form : String = ""
    var release_date : String = ""
    var release_year : String = ""
    
    //TO USE WITH SPOTIFY
    var title : String = ""
    var spotify_id : String = ""
    var spotify_url : String = ""
    var label_name : String = ""
    
    var imageArray : [CustomImage] = []
    
    var albumCoverImage : UIImage = UIImage()
}
