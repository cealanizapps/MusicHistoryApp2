//
//  CountryCore+CoreDataProperties.swift
//  TESTFINAL1
//
//  Created by User on 10/14/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension CountryCore {

    @NSManaged var countryName: String?
    @NSManaged var latitude: NSNumber?
    @NSManaged var longitude: NSNumber?
    @NSManaged var place_id: String?
    @NSManaged var numberOfArtists: NSNumber?
    @NSManaged var countryArtist: NSSet?

}
