//
//  ArtistCore+CoreDataProperties.swift
//  TESTFINAL1
//
//  Created by User on 10/12/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension ArtistCore {

    @NSManaged var country_of_origin: String?
    @NSManaged var decade: String?
    @NSManaged var entity_type: String?
    @NSManaged var id: String?
    @NSManaged var main_genre: String?
    @NSManaged var name: String?
    @NSManaged var spotify_href: String?
    @NSManaged var spotify_id: String?
    @NSManaged var artistCountry: CountryCore?

}
