//
//  AlbumCell.swift
//  TESTFINAL1
//
//  Created by User on 10/10/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Cell Class for Album Controller

class AlbumCell: UITableViewCell {

    @IBOutlet weak var albumCoverImage: UIImageView!
    
    @IBOutlet weak var albumNameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
