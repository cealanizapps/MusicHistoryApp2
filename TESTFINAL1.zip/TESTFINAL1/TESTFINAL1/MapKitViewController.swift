//
//  MapKitViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/13/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import CoreData
import MapKit

//controller to show last search results on a map

class MapKitViewController: UIViewController {

    
    @IBOutlet weak var mapView: MKMapView!
    
    var countryCoreArray : [CountryCore] = []
    
    var fetchedResultsController : NSFetchedResultsController!
    var managedObjectContext : NSManagedObjectContext!
    
    //    Declaration for Managers Instances
    let getDataManager = GetDataManager.sharedInstance
    let locationManager = LocationsManager.sharedInstance
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Get the app Managed object context
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        managedObjectContext = appDelegate.managedObjectContext
        
        //Setup the fetched results controller
        //Setup the fetch request
        let fetchRequest = NSFetchRequest()
        //Determines in what order we sort the results by
        let sortDescriptor = NSSortDescriptor(key: "countryName", ascending: true)
        //Pass the sort descriptors into an array for the fetch request
        fetchRequest.sortDescriptors = [sortDescriptor]
        //Set the entity so the fetch request knows what to fetch
        let entity = NSEntityDescription.entityForName("CountryCore", inManagedObjectContext: managedObjectContext)
        fetchRequest.entity = entity
        //Set the fetchedResultsController
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: "Root")
        

        
    }
    
//    Fetching Core Data to create locations
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        do {
            try fetchedResultsController.performFetch()
            
            countryCoreArray = fetchedResultsController.fetchedObjects as! [CountryCore]
            
            addLocationsToMap()
            
        } catch {
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    Adding locations to map
    func addLocationsToMap() {
        //Removes all existing annotations
        let allAnnotations = mapView.annotations
        mapView.removeAnnotations(allAnnotations)
        
        //Parse through the locations and add the annotations to the map
        for location in countryCoreArray {
            let coordinate = CLLocationCoordinate2D(latitude: Double(location.latitude!), longitude: Double(location.longitude!))
            let locationTitle = location.countryName! + "-" + String(location.numberOfArtists)
            let annotation = MyAnnotation(title: locationTitle, subtitle: "Lat: \(Float(location.latitude!)) Long: \(Float(location.longitude!))", coordinate: coordinate)
            mapView.addAnnotation(annotation)
        }
    }

}
