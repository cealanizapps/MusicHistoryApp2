//
//  albumSpotifyTableViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/8/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Controller to show all the albums related to the choosen artist
//Showing album covers

class albumSpotifyTableViewController: UITableViewController {

//    Objects to receive information
    var artistSpotifyID : String!
    var artistArrayIndex : Int!
    
    //    Declaration for Managers Instances
    let getDataManager = GetDataManager.sharedInstance
    
    var albumArray : [Album]!
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        call function to get Albums list
        getDataManager.getALBUMSpotifyList(artistSpotifyID, completionHandler: {
                dispatch_async(dispatch_get_main_queue()) {
                    self.tableView.reloadData()
                }
            })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return getDataManager.albumArray.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as! AlbumCell
        
        let currentAlbum = getDataManager.albumArray[indexPath.row]
        
        cell.albumNameLabel.text = currentAlbum.title
        
        // If image array is not empty -> They have an image url
        //   Getting the image and putting into de class, to have everything at once
        if currentAlbum.imageArray.count > 0
        {
            getDataManager.downloadAlbumImage(indexPath.row, completionHandler: {
                  dispatch_async(dispatch_get_main_queue()) {
                    cell.albumCoverImage.image = currentAlbum.albumCoverImage
                  }
            })
        }
        
        return cell
        
    }
    
    // MARK: - Segues
//    Setting all data to send data to Track Controller
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "segueAlbumToTrackSpo" {
            if let indexPath = tableView.indexPathForSelectedRow {
                
                if let destination = segue.destinationViewController as? AlbumTrackSpotifyViewController {
                    
                    let albumSpotifyID = getDataManager.albumArray[indexPath.row].spotify_id
                    
                    destination.artistSpotifyID = artistSpotifyID
                    destination.albumSpotifyID = albumSpotifyID
                    destination.albumArrayIndex = indexPath.row
                    destination.artistName = getDataManager.artistArray[artistArrayIndex].name
                    
                }
            }
        }
    }

}
