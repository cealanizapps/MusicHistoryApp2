//
//  LocationObject.swift
//  TESTFINAL1
//
//  Created by User on 10/13/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import MapKit

//Annotation Object Class

class MyAnnotation : NSObject, MKAnnotation {
    var title: String?
    var subtitle: String?
    var coordinate: CLLocationCoordinate2D
    
    init(title: String?, subtitle: String?, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.subtitle = subtitle
        self.coordinate = coordinate
        super.init()
    }
}

//Location Object Class

class LocationObject : NSObject {
    var latitude : Float = 0
    var longitude : Float = 0
    var locationName : String = ""
    var rating : Float = 0
    var address : String = ""
    var iconURL : String = ""
    var typesOfEstablishment : [String] = [] //Indicates what types of services, i.e. bar, lodging, restaurant, etc.
    var iconImage : UIImage?
}
