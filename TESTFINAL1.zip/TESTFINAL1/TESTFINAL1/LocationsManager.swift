//
//  LocationsManager.swift
//  TESTFINAL1
//
//  Created by User on 10/13/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import CoreLocation

//MARK : Class used to get Country Coordinate as manager
class LocationsManager: NSObject, CLLocationManagerDelegate {
    
//    Objects instances
    static let sharedInstance = LocationsManager()
    private override init() {super.init()}
    private let locationManager = CLLocationManager()
    private let locationsAdapter = LocationsAdapter()
    
    
    //        MARK : Get country coordinates
    func getCountryCoordinates(country: String, completionHandler : (latitude: Double, longitude: Double, place_id: String) -> Void)
    {
//        Call function that gets coordinate for a given country
        locationsAdapter.getCountryCoordinates(country) { (latitude, longitude, place_id) in
            completionHandler(latitude: latitude, longitude: longitude, place_id: place_id)
        }
    }


//    MARK : Download images for table
} //CLASS