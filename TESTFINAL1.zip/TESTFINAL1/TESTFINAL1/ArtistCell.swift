//
//  ArtistCell.swift
//  TESTFINAL1
//
//  Created by User on 10/6/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Cell Class for Artist controller

class ArtistCell: UITableViewCell {

    @IBOutlet weak var nameArtistLabel: UILabel!
    
    @IBOutlet weak var detailsArtistButton: UIButton!
    
    @IBOutlet weak var albumsArtistButton: UIButton!
    
    @IBOutlet weak var imageArtist: UIImageView!
    
    @IBOutlet weak var countryArtistLabel: UILabel!
    
    @IBOutlet weak var decadesArtist: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
