//
//  artistMasterTableViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/7/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

//This controller is used to show all the artists that belong to specified Genre or Decade
//This is the most important controller for this app
//Shows the artist list
//Manages the pictures link for the artist
//Manages artists' pictures downloading
//Manages CoreData storing

import UIKit
import CoreData

class artistMasterTableViewController: UITableViewController {

    var genreToSearch : String!
    var decadeToSearch : String!
    var genre : String!
    var decades : String!
    
//    Declaration for Managers Instances
    let getDataManager = GetDataManager.sharedInstance
    let locationManager = LocationsManager.sharedInstance
    
//    CoreDate Objects
    var countryCoreArray : [CountryCore] = []
    
    var fetchedResultsController : NSFetchedResultsController!
    var managedObjectContext : NSManagedObjectContext!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // When controller is called by Genre
//        Goes for the Artists array
        if (genreToSearch != nil) {
            self.title = genre + " Artists"
            getDataManager.getARTISTList(genreToSearch, completionHandler: {
                dispatch_async(dispatch_get_main_queue()) {
                    self.tableView.reloadData()

                    self.addCountryCore()

                }
            })
        }
            // When controller is called by Decade
            //        Goes for the Artists array
        else if (decadeToSearch != nil) {
            self.title = decades + " Artists"
            getDataManager.getARTISTList(decadeToSearch, completionHandler: {
                dispatch_async(dispatch_get_main_queue()) {
                    self.tableView.reloadData()
                    
                    self.addCountryCore()

                }
            })
        }
        
//        Going to setup CoreData
        doCoreDataSetup()
    }
    
//    Function to Setup CoreData
//    about Objects and deleting previous information
    func doCoreDataSetup() {
        // Do any additional setup after loading the view.
        //Get the app Managed object context
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        managedObjectContext = appDelegate.managedObjectContext
        
        //Setup the fetched results controller
        //Setup the fetch request
        let fetchRequest = NSFetchRequest()
        //Determines in what order we sort the results by
        let sortDescriptor = NSSortDescriptor(key: "countryName", ascending: true)
        //Pass the sort descriptors into an array for the fetch request
        fetchRequest.sortDescriptors = [sortDescriptor]
        //Set the entity so the fetch request knows what to fetch
        let entity = NSEntityDescription.entityForName("CountryCore", inManagedObjectContext: managedObjectContext)
        fetchRequest.entity = entity
        //Set the fetchedResultsController
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: "Root")

//        Deleting Previous Information
        DeleteArray()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return getDataManager.artistArray.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as! ArtistCell
        
        let currentArtist = getDataManager.artistArray[indexPath.row]
        
//        Setting information on the cell
        cell.nameArtistLabel.text = currentArtist.name
        cell.countryArtistLabel.text = currentArtist.country_of_origin
        cell.decadesArtist.text = currentArtist.decade
        
//        Setting selectors for buttons in the cell
//        Setting the index as tag in both cases
        cell.albumsArtistButton.addTarget(self, action: #selector(ArtistAlbums), forControlEvents: UIControlEvents.TouchUpInside)
        cell.albumsArtistButton.tag = indexPath.row
        
        cell.detailsArtistButton.addTarget(self, action: #selector(ArtistDetails), forControlEvents: UIControlEvents.TouchUpInside)
        cell.detailsArtistButton.tag = indexPath.row
        
        
//        To catch the Artist Image up
//        sending for the image
        if currentArtist.imageArray.count > 0
        {
            getDataManager.downloadArtistImage(indexPath.row, completionHandler: {
                dispatch_async(dispatch_get_main_queue()) {
                    cell.imageArtist.image = currentArtist.artistImage
                }
            })
        }

        return cell
    }
    
//    ********************************
//    COREDATA
//    ********************************
    
//    Function to Read CountryCore Class and add if needed
//    Having the country as parameter
    func addCountryCore(){
        
        for country in getDataManager.countryOccurArray
        {
        
            let capCountryName = country.0
            
    // Check if the country name is already in the Core Data Array
            let predicate = NSPredicate(format: "countryName contains[cd] %@", capCountryName)
            fetchedResultsController.fetchRequest.predicate = predicate
            
            //Perform the fetch
            do {
                try fetchedResultsController.performFetch()
                
                if fetchedResultsController.fetchedObjects?.count > 0 {//Country already exists
                    return //Display an alert saying Country already exists
                } else {//Create the Country
                    
                    locationManager.getCountryCoordinates(capCountryName, completionHandler: {(latitude, longitude, place_id) in
                        dispatch_async(dispatch_get_main_queue()) {
                            
//                            Adding a country in CoreData once that we have its coordinates
                            self.AddCountryAfter(capCountryName, latitude: latitude, longitude: longitude, place_id: place_id, numberArtists: country.1)
                            
                        }
                    })
                }
            } catch {
                NSLog("Something went wrong with the fetch request")
            }
        }
    }
    
//    Adding a country to CoreData Objects
    func AddCountryAfter(countryName: String, latitude: Double, longitude: Double, place_id: String, numberArtists: Int)
    {
        do
        {
            let newCountry = NSEntityDescription.insertNewObjectForEntityForName("CountryCore", inManagedObjectContext: managedObjectContext) as! CountryCore
            newCountry.countryName = countryName
            newCountry.latitude = latitude
            newCountry.longitude = longitude
            newCountry.place_id = place_id
            newCountry.numberOfArtists = numberArtists
            
            try managedObjectContext.save()
        }catch{
            NSLog("Something went wrong with the fetch save")
        }
    }
    
    
//    Deleting CoreData information of previous searches
    func DeleteArray()
    {
        //Get the app Managed object context
        do {
            try fetchedResultsController.performFetch()
            
            //        Create an Array of CountryCore
            countryCoreArray = fetchedResultsController.fetchedObjects as! [CountryCore]

            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            managedObjectContext = appDelegate.managedObjectContext
            
//            running trough array for deleting each objects
            if countryCoreArray.count > 0
                {
                for index in 0...countryCoreArray.count-1
                {
                    managedObjectContext.deleteObject(countryCoreArray[index])
                    appDelegate.saveContext()
                    
                }
            }
            
            countryCoreArray.removeAll()
            
        }catch {
            NSLog("Something went wrong with the fetch request or save")
        }
    }
    

    //        Here to call Artist's Albums
    //Call new prodecure that calls Spotify Information, make sure that it parses albums and tracks
    func ArtistAlbums(sender: UIButton)
    {
        _ = sender.tag
    }

    //        Here to call Artist's Details
    //        Call functionality for Photos and then Social Media
    func ArtistDetails(sender: UIButton)
    {
        _ = sender.tag
        
    }
    
//    // MARK: - Segues
//    I need to segues here, one for Albums and one for details
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
//        Set the index of choosen artist on the artistArray to send it as parameter
        let index = sender?.tag
        
//        To call Artist Details controller
//        With all the social Media URL
//        Sending the index of the choosen Artist on the ArtistArray
        if segue.identifier == "segueArtistDetails" {
            
            if let destination = segue.destinationViewController as? ArtistDetailViewController {
                                
                destination.artistArrayIndex = index
                
            }
        }
            
//        to call Albums controller for this artist
//        Sending the index of the choosen Artist on the ArtistArray
        else if segue.identifier == "segueArtistAlbumsSpo" {
                
            if let destination = segue.destinationViewController as? albumSpotifyTableViewController {
                    
                destination.artistSpotifyID = getDataManager.artistArray[index!].spotify_id
                destination.artistArrayIndex = index
                    
            }
        }
    }
    
}
