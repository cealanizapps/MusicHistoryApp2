//
//  ArtistDetailViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/11/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//


//This controller is for showing all social media url for the choosen artist
import UIKit

class ArtistDetailViewController: UIViewController {

    @IBOutlet weak var artistImage: UIImageView!
    
    @IBOutlet weak var artistNameLabel: UILabel!
    
    @IBOutlet weak var mainGenreLabel: UILabel!
    
    @IBOutlet weak var countryLabel: UILabel!
    
    @IBOutlet weak var decadesLabel: UILabel!
    
    @IBOutlet weak var entityTypeLabel: UILabel!
    
    @IBOutlet weak var oficialURLBtn: UIButton!
    
    @IBOutlet weak var spotifyURLBtn: UIButton!
    
    @IBOutlet weak var youTubeURLBtn: UIButton!
    
    @IBOutlet weak var vevoURLBtn: UIButton!
    
    @IBOutlet weak var facebookURLBtn: UIButton!
    
    @IBOutlet weak var twitterURLBtn: UIButton!
    
    @IBOutlet weak var lastFMURLBtn: UIButton!
    
    @IBOutlet weak var instagramURLBtn: UIButton!
    
    @IBOutlet weak var allMusicURLBtn: UIButton!
    
    @IBOutlet weak var bbcURLBtn: UIButton!
    
    @IBOutlet weak var wikipediaURLBtn: UIButton!
    
    @IBOutlet weak var musiBrainzURLBtn: UIButton!
    
    
    var artistArrayIndex : Int!
    
    //    Declaration for Managers Instances
    let getDataManager = GetDataManager.sharedInstance
    
//    Using a singleton instance for using object already retrieved
//    Setting all information from retrieved object to screen objects
    override func viewDidLoad() {
        super.viewDidLoad()

        let currentArtist = getDataManager.artistArray[artistArrayIndex]
        
        artistImage.image = currentArtist.artistImage
        artistNameLabel.text = currentArtist.name
        mainGenreLabel.text = currentArtist.main_genre
        countryLabel.text = currentArtist.country_of_origin
        decadesLabel.text = currentArtist.decade
        entityTypeLabel.text = currentArtist.entity_type
        
        getDataManager.getSOCIALMETRICSList(currentArtist.id, completionHandler: {
            dispatch_async(dispatch_get_main_queue()) {
                
                self.oficialURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].official_url, forState: .Normal)
                
                self.youTubeURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].youtube_url, forState: .Normal)
                
                self.spotifyURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].spotify_url, forState: .Normal)
                
                self.vevoURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].vevo_url, forState: .Normal)
                
                self.facebookURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].facebook_url, forState: .Normal)
                
                self.twitterURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].twitter_url, forState: .Normal)

                self.lastFMURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].lastfm_url, forState: .Normal)
                
                    self.instagramURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].instagram_url, forState: .Normal)
                
                self.allMusicURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].allmusic_url, forState: .Normal)
                
                self.bbcURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].bbc_url, forState: .Normal)
                
                self.wikipediaURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].wikipedia_url, forState: .Normal)
                
                self.musiBrainzURLBtn.setTitle(self.getDataManager.socialMetricsArray[0].musicbrainz_url, forState: .Normal)
                
            }
        })
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
//  MARK : Function to perform all urls on the web controller
    var urlToPerform : String!
    
    @IBAction func urlBtnPressed(sender: UIButton) {
        
//        Set url to show it on next controller
        urlToPerform = sender.titleLabel?.text
        
        self.performSegueWithIdentifier("segueWebUrl", sender: self)
        
    }
    

//    Preparing web controller sending information of the url
    // MARK: - Segues
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "segueWebUrl" {
            
                if let destination = segue.destinationViewController as? WebDetailsViewController {
                    
                    destination.urlToPerform = urlToPerform
                    
                }
        }
    }
    

} //CLASS
