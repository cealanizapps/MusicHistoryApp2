//
//  Artist.swift
//  TESTFINAL1
//
//  Created by User on 9/29/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit
import CoreData

//Artist Class

class Artist: NSObject {

    var artist_ref_id : String = ""
	var country_of_origin : String = ""
    var decade : String = ""
    var entity_type : String = ""
    var gender : String = ""
    var id : String = ""
    var main_genre : String = ""
    var musicbrainz_id : String = ""
    var musicbrainz_image_url : String = ""
    var name : String = ""
	var sort_name : String = ""
    var spotify_id : String = ""
    var spotify_href : String = ""
    var youtube_id : String = ""

    var imageArray : [CustomImage] = []
    
    var artistImage : UIImage = UIImage()
}


class CustomImage: NSObject {
    var width : Int = 0
    var height : Int = 0
    var url : String = ""
    var image : UIImage = UIImage()
}