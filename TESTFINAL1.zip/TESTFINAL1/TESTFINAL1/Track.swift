//
//  Track.swift
//  TESTFINAL1
//
//  Created by User on 9/29/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//Track Class

class Track: NSObject {

    var album_title  : String = ""
    var artist_name : String = ""
    var duration : String = ""
    var entity_type : String = ""
    var id : String = ""
    var isrc : String = ""
    var label_name : String = ""
    var main_genre : String = ""
    var original_release_year : String = ""
    var popularity : String = ""
    var release_year : String = ""
    var title : String = ""
    var track_album_id : String = ""
    var track_album_ref_id : String = ""
    var track_artist_id : String = ""
    var track_artist_ref_id : String = ""
    var track_index : String = ""
    var track_ref_id : String = ""
    var track_spotify_id : String = ""
    var track_youtube_id : String = ""
    
    
    var disc_number : Int = 0
    var duration_ms : Int = 0
    var explicit : Bool = false
    var href : String = ""
    var spotifyId : String = ""
    var name : String = ""
    var preview_url : String = ""
    var track_number : Int = 0
    var spotifyUrl : String = ""
    
}
