//
//  WebDetailsViewController.swift
//  TESTFINAL1
//
//  Created by User on 10/7/16.
//  Copyright © 2016 Carlos Enrique Alaniz. All rights reserved.
//

import UIKit

//This controller is to show web url for the artist

class WebDetailsViewController: UIViewController {

    @IBOutlet weak var navigationBar: UINavigationBar!
    
    @IBOutlet weak var webView: UIWebView!
    
    var urlToPerform : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print(urlToPerform)
        
//        Just load the given URL 
        webView.loadRequest(NSURLRequest(URL: NSURL(string: urlToPerform)!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    Function to get back action
    @IBAction func backAction(sender: AnyObject) {
        if webView.canGoBack {
            webView.goBack()
        }
        
    }
    
//    Function to get forward action
    @IBAction func forwardAction(sender: AnyObject) {
        if webView.canGoForward {
            webView.goForward()
        }
    
    }
    
//    Function to get stop action
    @IBAction func stopAction(sender: AnyObject) {
        webView.stopLoading()
    
    }
    
//    Function to refresh webview
    @IBAction func refreshAction(sender: AnyObject) {
        webView.reload()
    
    }
  

}
